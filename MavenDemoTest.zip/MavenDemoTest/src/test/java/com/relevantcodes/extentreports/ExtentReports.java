package com.relevantcodes.extentreports;

public class ExtentReports {

}
